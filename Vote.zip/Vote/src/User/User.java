
package User;
import UserVerify.UserVerify;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.logging.Level;
import java.util.logging.Logger;
public class User extends JFrame
{
    public static String input;
    public User() throws Exception
    {
               
                JFrame jframe1 = new JFrame();
                JTextArea t1=new JTextArea();
                JLabel e;
                JButton b11;
                
                e = new JLabel("Enter your Voter Id");
                JTextField j1 = new JTextField(20);
                b11 = new JButton("ENTER");
                b11.setBounds(150, 150, 200, 30);
                jframe1.setTitle("Voting system");
                
                Font font = new Font("Courgette", Font.BOLD, 40);
                e.setFont(font); 
                e.setForeground(Color.decode("#D01110"));
                //jframe.add(l1);
                jframe1.add(e);
                
                JLabel label = new JLabel();
                ImageIcon imageIcon = new ImageIcon("vote2.jpg");        
                label.setIcon(imageIcon);
                jframe1.getContentPane().add(label);
                label.setSize(450, 205);
                label.setVisible(true);
                
                jframe1.add(j1);
                jframe1.add(b11);
                jframe1.setSize(500,600);
                //jframe1.setTitle("Online voting system");
                jframe1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                jframe1.setLayout(new FlowLayout());
                jframe1.setVisible(true);
                jframe1.getContentPane().setBackground(Color.decode("#f6cf92"));
                
                b11.addActionListener(new ActionListener()
                {
                    @Override
                    public void actionPerformed(ActionEvent ae)
                    {
                        input = j1.getText();
                        if (ae.getSource() == b11) 
                        {
                            
                            try{
                                BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\shrik\\OneDrive\\Documents\\NetBeansProjects\\Vote\\src\\voterids"));   
                                String line;
                                while ((line = reader.readLine()) != null) 
                                {
                                if (line.equals(input)) 
                                {
                                    UserVerify userVerify = new UserVerify();
                                    jframe1.dispose();
                                    return;
                                }
                                }
                                JOptionPane.showMessageDialog(null, "User does not exist");
                                return;
                                }
                             catch (Exception ex) {
                            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        jframe1.dispose();
                        
                    }
                }
                }
                );
    }
}
   
                
