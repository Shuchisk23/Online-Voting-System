
package UserCaste;
import Vote1.Vote1;
import static Vote1.Vote1.p11;
import static Vote1.Vote1.p21;
import static Vote1.Vote1.p31;
import javax.swing.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
public class UserCaste extends JFrame
{
    public UserCaste() throws Exception
    {
                        JFrame jframe2 = new JFrame();
                        JLabel o;
                        JRadioButton p1,p2,p3;
                        JButton v;
                        JTextArea t1 = new JTextArea();
                      
                        try(BufferedReader brk = new BufferedReader(new FileReader("C:\\Users\\shrik\\OneDrive\\Documents\\NetBeansProjects\\Vote\\src\\candidate list.txt")))
                        {
                          String s;
                          t1.append("\n");
                        while((s=brk.readLine())!=null)
                        {
                            
                            t1.append("\t");
                            t1.append(s);
                            t1.append("\t");
                        }  
                        t1.append("\n");
                        }
                        catch (IOException e) 
                        {
                     
                            JOptionPane.showMessageDialog(null, "An error occured in reading the file");
                        }    
                        Font font1 = t1.getFont();
                        float size1; 
                        size1 = font1.getSize() + 5.0f;
                        t1.setFont(font1.deriveFont(size1));
                        
                        jframe2.add(t1);
                        t1.setEditable(false);
                        
                        jframe2.setSize(1000,600);
                        jframe2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        jframe2.setLayout(new FlowLayout());
                        jframe2.setVisible(true);
                        jframe2.getContentPane().setBackground(Color.WHITE);
                        jframe2.setTitle("Voting system");
                        //ImageIcon i1 = new ImageIcon("\"C:\\Users\\shrik\\OneDrive\\Pictures\\WhatsApp Image 2022-08-31 at 8.41.51 PM.jpeg\"");
                        
                        JLabel label1 = new JLabel();
                        ImageIcon imageIcon1 = new ImageIcon("BTS Proof Album.jpg");        
                        label1.setIcon(imageIcon1);
                        jframe2.getContentPane().add(label1);
                        label1.setSize(300, 300);
                        label1.setVisible(true);
                        
                        
                        JLabel label2 = new JLabel();
                        ImageIcon imageIcon2 = new ImageIcon("BTS.jpg");        
                        label2.setIcon(imageIcon2);
                        jframe2.getContentPane().add(label2);
                        label2.setSize(300, 300);
                        label2.setVisible(true);
                        
                        
                        JLabel label3 = new JLabel();
                        ImageIcon imageIcon3 = new ImageIcon("bts1.jpg");        
                        label3.setIcon(imageIcon3);
                        jframe2.getContentPane().add(label3);
                        label3.setSize(300, 300);
                        label3.setVisible(true);
                        
                        
                        o = new JLabel("CASTE YOUR VOTE");
                        o.setSize(1000, 1500);
                        Font font = new Font("Courgette", Font.BOLD, 40);
                        o.setFont(font); 
                        o.setForeground(Color.BLACK);
                        jframe2.add(o);
                        
                        JLabel p = new JLabel("                                                                                                                                                                                      ");
                        jframe2.add(p);
                        
                        
                        
                        p1 = new JRadioButton("PARTY A");
                        p2 = new JRadioButton("PARTY B");
                        p3 = new JRadioButton("PARTY C");
                        p1.setBounds(50, 90, 200, 30);
                        p2.setBounds(10, 250, 200, 30);
                        p3.setBounds(150, 250, 200, 30);
                        p1.addActionListener(new ActionListener() 
                        {
                            @Override
                            public void actionPerformed(ActionEvent evt) 
                            {
                                p1ActionPerformed(evt);
                            }

                            private void p1ActionPerformed(ActionEvent evt) 
                            {
                                if (p1.isSelected())
                                {
                                    p2.setSelected(false);
                                    p3.setSelected(false);
                                }
                            }
                        });
                        
                        jframe2.add(p1);
                        
                        p2.addActionListener(new ActionListener() 
                        {
                            public void actionPerformed(ActionEvent evt) 
                            {
                                p1ActionPerformed(evt);
                            }

                            private void p1ActionPerformed(ActionEvent evt)
                            {
                                if (p2.isSelected())
                                {
                                    p1.setSelected(false);
                                    p3.setSelected(false);
                                }
                            }
                        });
                        jframe2.add(p2);
                        
                        p3.addActionListener(new ActionListener() 
                        {
                            @Override
                            public void actionPerformed(ActionEvent evt) 
                            {
                                p1ActionPerformed(evt);
                            }

                            private void p1ActionPerformed(ActionEvent evt)
                            {
                                if (p3.isSelected())
                                {
                                    p1.setSelected(false);
                                    p2.setSelected(false);
                                }
                            }
                        });
                        jframe2.add(p3);
                        v = new JButton("VOTE");
                        jframe2.add(v);
                        v.addActionListener(new ActionListener()
                        {
                            @Override
                            public void actionPerformed(ActionEvent e) 
                                {
                                    if(p1.isSelected())
                                    {
                                        p11++;
                                    }
                                    else if(p2.isSelected())
                                    {
                                        p21++;
                                    }
                                    else if(p3.isSelected())
                                    {
                                        p31++;
                                    }
                                    else{
                                        JOptionPane.showMessageDialog(null, "Select a Party");
                                    }
                                    if(p1.isSelected()||p2.isSelected()||p3.isSelected())
                                    {
                                        JOptionPane.showMessageDialog(null, "Thank you for your vote");
                                        String cmd = e.getActionCommand();

                                        if(cmd.equals("VOTE"))
                                        {
                                        jframe2.dispose();
                                            try {
                                            Vote1 vote1 = new Vote1();
                                            } catch (Exception ex) {
                                                JOptionPane.showMessageDialog(null, "An error occured!!"); 
                                            }
                    
                                        }
                                    }
                                    
                        }
                        
                    }); 
    }
}
