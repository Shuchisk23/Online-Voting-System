
package UserVerify;
import User.User;
import static User.User.input;
import UserCaste.UserCaste;
import java.io.*;
import java.util.*;
import javax.swing.*;
public class UserVerify extends JFrame
{
    private HashSet<String> uniqueValues = new HashSet<>();
    public UserVerify() throws Exception 
    {
        try {
            File file = new File("C:\\Users\\shrik\\OneDrive\\Documents\\NetBeansProjects\\Vote\\src\\ids");

            if (file.exists()) {
                Scanner scanner = new Scanner(file);

                while (scanner.hasNextLine()) {
                    String line = scanner.nextLine();
                    uniqueValues.add(line);
                }
                scanner.close();
            }
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(this, "File not found: " + e.getMessage());
        }
        if (!uniqueValues.contains(input)) {
            uniqueValues.add(input);
            UserCaste userCaste = new UserCaste();
            try {
                FileWriter writer = new FileWriter("C:\\Users\\shrik\\OneDrive\\Documents\\NetBeansProjects\\Vote\\src\\ids");

                for (String value : uniqueValues) 
                { 
                    writer.write(value + "\n");
                }
                writer.close();
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "Error writing to file: " + e.getMessage());
            }
        } 
        else 
        {
            JOptionPane.showMessageDialog(this, "Already voted!!");
            User user = new User();
        }
        
    }
    public static void main(String[] args) throws Exception 
     {
        new UserVerify();
    }
}
        
        