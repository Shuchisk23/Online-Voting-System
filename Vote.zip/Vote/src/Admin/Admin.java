
package Admin;
import AdminLogin.AdminLogin;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Admin extends JFrame
{
    public Admin()
    {
        JFrame jframe3 = new JFrame();
               
                JLabel f,i,j;
                JButton b01;
                f = new JLabel("ADMIN LOGIN");
                
                Font font = new Font("Courgette", Font.BOLD, 40);
                f.setFont(font); 
                f.setForeground(Color.decode("#E49B0F"));
                
                
                JTextField j1 = new JTextField(15);
                JPasswordField j2 = new JPasswordField(15);
                i = new JLabel("Username:");
                j = new JLabel("Password:");
                i.setForeground(Color.decode("#E49B0F"));
                j.setForeground(Color.decode("#E49B0F"));
                
                
                jframe3.setSize(300,300);
                jframe3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                jframe3.setLayout(new FlowLayout());
                jframe3.setVisible(true);
                jframe3.getContentPane().setBackground(Color.decode("#097969"));
                jframe3.setTitle("Voting system");
                jframe3.add(f);
                jframe3.add(i);
                jframe3.add(j1);
                jframe3.add(j);
                jframe3.add(j2);
                b01 = new JButton("Enter");
                jframe3.add(b01);
                b01.addActionListener(new ActionListener()
                {
                    
                    @Override
                    public void actionPerformed(ActionEvent e) 
                    {
                        String Username = j1.getText();
                        var Password1 = j2.getText();

                        if (Username.equals("admin") && Password1.equals("admin"))
                        {
                            AdminLogin adminLogin = new AdminLogin();
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null, "Username or Password mismatch ");
                        }
                         jframe3.dispose();
    }
                });
                        }
}


