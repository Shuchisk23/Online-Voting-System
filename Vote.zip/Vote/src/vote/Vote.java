package vote;
import Vote1.Vote1;
import java.io.IOException;
public class Vote 
{
   public static void main(String args[]) throws IOException 
    {
        Vote1 vote = new Vote1();
    }
}