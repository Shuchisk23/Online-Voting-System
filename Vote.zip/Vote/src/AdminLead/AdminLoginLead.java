
package AdminLead;

import static Vote1.Vote1.p11;
import static Vote1.Vote1.p21;
import static Vote1.Vote1.p31;
import javax.swing.JOptionPane;

public class AdminLoginLead
{
    public AdminLoginLead()
    {
                                        int r1 = p11;
                                        int r2 = p21;
                                        int r3 = p31;

                                        if(r1>r2 && r1>r3){

                                            JOptionPane.showMessageDialog(null, "Party A "+r1+"\nParty B "+r2+"\nParty C "+r3+"\n\nPARTY A has a lead");
                                        }
                                        else if(r2>r1&&r2>r3){
                                            JOptionPane.showMessageDialog(null, "Party A "+r1+"\nParty B "+r2+"\nParty C "+r3+"\n\nPARTY B has a lead");
                                        }
                                        else if(r3>r1&&r3>r2){
                                            JOptionPane.showMessageDialog(null, "Party A "+r1+"\nParty B "+r2+"\nParty C "+r3+"\n\nPARTY C has a lead");
                                        }
                                        else if(r1==r2&&r2==r3&&r3==r1&&r1!=0&&r2!=0&&r3!=0)
                                        {
                                            JOptionPane.showMessageDialog(null, "Party A "+r1+"\nParty B "+r2+"\nParty C "+r3+"\n\nIts a draw between all 3 parties");
                                        }
                                        else if(r1==0&&r2==0&&r3==0)
                                        {
                                            JOptionPane.showMessageDialog(null, "Party A "+r1+"\nParty B "+r2+"\nParty C "+r3+"\n\nThe election has to begin"); 
                                        }
                                        else if(r1==r2)
                                        {
                                            JOptionPane.showMessageDialog(null, "Party A "+r1+"\nParty B "+r2+"\nParty C "+r3+"\n\nIts a draw between Party A and Party B");
                                        }
                                        else if(r1==r3)
                                        {
                                            JOptionPane.showMessageDialog(null, "Party A "+r1+"\nParty B "+r2+"\nParty C "+r3+"\n\nIts a draw between Party A and Party C");
                                        }
                                        else 
                                        {
                                            JOptionPane.showMessageDialog(null, "Party A "+r1+"\nParty B "+r2+"\nParty C "+r3+"\n\nIts a draw between Party B and Party C");
                                        }
                                        System.exit(0);
                                    }
    }

