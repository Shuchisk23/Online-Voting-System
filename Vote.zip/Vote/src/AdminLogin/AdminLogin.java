
package AdminLogin;

import AdminLead.AdminLoginLead;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.*;
import java.awt.event.*;
import javax.swing.ImageIcon;
import Admin.Admin;
public class AdminLogin extends JFrame 
{
    public AdminLogin()
    {
        JFrame jframe4 = new JFrame();
                           
                            jframe4.setSize(500,500);
                            jframe4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                            jframe4.setLayout(new FlowLayout());
                            jframe4.setVisible(true);
                            jframe4.getContentPane().setBackground(Color.WHITE);
                            jframe4.setTitle("Voting System");
                            
                            JLabel label = new JLabel();
                            ImageIcon imageIcon = new ImageIcon("vote5.jpg");        
                            label.setIcon(imageIcon);
                            jframe4.getContentPane().add(label);
                            label.setSize(450, 205);
                            label.setVisible(true);
                        
                            JLabel l1;
                            l1 = new JLabel("Click to view the results");
                            
                            
                            Font font = new Font("Courgette", Font.BOLD, 40);
                            l1.setFont(font); 
                            l1.setForeground(Color.BLACK);
                            jframe4.add(l1);
                            JButton c;
                            c  = new JButton("Check!");
                            jframe4.add(c);
                            c.addActionListener(new ActionListener()
                            {
                                
                                @Override
                                public void actionPerformed(ActionEvent e) 
                                {
                                    AdminLoginLead adminLead = new AdminLoginLead();
                                    jframe4.dispose();
                                }

                                
                            });
        
    }
                            
                        
}
