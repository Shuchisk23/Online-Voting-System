
package Vote1;
import Admin.Admin;
import User.User;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import javax.swing.*;
public class Vote1 extends JFrame 
{
    public static int p11 = 0;
    public static int p21 = 0;
    public static int p31 = 0;
    public Vote1() throws IOException
            
    {
        JButton b1,b2;
        JFrame jframe;
        JLabel label = new JLabel();
        JLabel l1;
        jframe = new JFrame();
        jframe.setSize(500,500);
        jframe.setTitle("Voting system");
        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jframe.setLayout(new FlowLayout());
        jframe.setVisible(true);
        jframe.getContentPane().setBackground(Color.decode("#87ceeb"));
        l1 = new JLabel("VOTING SYSTEM");
        Font font = new Font("Courgette", Font.BOLD, 60);
        l1.setFont(font); 
        l1.setForeground(Color.WHITE);
        jframe.add(l1);
        JLabel y = new JLabel("            ");
        jframe.add(y);
        ImageIcon imageIcon = new ImageIcon("vote1.jpg");        
        label.setIcon(imageIcon);
        jframe.getContentPane().add(label);
        label.setSize(400, 224);
        label.setVisible(true);
        JLabel y1 = new JLabel("         ");
        jframe.add(y1);
        JLabel x = new JLabel("            ");
        jframe.add(x);
        
        b1 = new JButton("USER LOGIN");
        jframe.add(b1);
        
        JLabel x1 = new JLabel("    ");
        jframe.add(x1);

        b2 = new JButton("ADMIN LOGIN");
        jframe.add(b2);
        
        JLabel x11 = new JLabel("           ");
        jframe.add(x11);
        
        b1.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                try {
                    jframe.dispose();
                    User user = new User();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "An error occured!!"); 
                }
            }
        });
        b2.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                try {
                    jframe.dispose();
                    Admin admin = new Admin();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "An error occured!!"); 
                }
            
            }
        });
    }
}
